﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TP4VectorSpace
{
    class Program
    {
        //static string[] docs = {
        //     "English tutorial and fast track",
        //    "learning latent semantic indexing",
        //    "Book on semantic indexing",
        //    "Advance in structure and semantic indexing",
        //    "Analysis of latent structures"
        //    };

        static string[] docs =
        {
            "English fast fast track track latent",
            "English English learning learning latent latent latent semantic indexing learning latent semantic indexing ",
             "Book Book on semantic semantic semantic indexing",
            "Advance structure and semantic semantic indexing",
            "Analysis Analysis Analysis of latent latent latent latent structures structures structure structure"
        };

        static string[] q = {

                "latent English",              //  "Advance structure",
                  "Analysis latent",
                "structure Analysis",                //"latent AND learning",                //"English and not Semantic",
                "Advance and structure AND analysis",   
            };

        static List<string> querys;
        static List<string> terms = new List<string>();

        static int[][] matrix;
        static int[][] queryMatrix;
        
        static int N;

        public static int[] df;
        public static double[] idf;
        //public static double[] tf_idf;
        public static List<VectorSpace> vectors;//= new List<VectorSpace>();
        static List<VectorSpaceQ> vectorsQuerys;// = new List<VectorSpace>();
        static void Main(string[] args)
        {
            init();
            BuildDocsMatrix();
            BuildQureysMatrix();

            Calcule_df();
            PrintMatrix();
            BuildDocsVector();
            BuildQurysVector();
            

            while (true)
            {
                querys = new List<string>();
                queryMatrix[0] = new int[1];
                N = docs.Length + 1;
                vectorsQuerys = new List<VectorSpaceQ>();

                Print("Enter the query:");
                querys.Add(Read());

                BuildQureysMatrix();
                BuildQurysVector();

            }
        }

        static void BuildDocsVector()
        {
        
            for (int i = 0; i < matrix[0].Length; i++)
            {
                Console.WriteLine("\nDoc " + (i+1) + "\n");
                vectors.Add(new VectorSpace(i, matrix));
                Console.Write(vectors[i].Print() + "\n----\n");
            }
        }
       
        private static void BuildQurysVector()
        {

            int nbrDocs = docs.Length;

            //, vectorsQuerys
            for (int i = 0; i < queryMatrix[0].Length; i++)
            {
                Console.WriteLine("\nQuery " + i + " " +querys[i]+  "\n");
                vectorsQuerys.Add(new VectorSpaceQ(i, queryMatrix ,nbrDocs));
                Console.Write(vectorsQuerys[i].Print() + "\n----\n");
            }
            //result of query
            
            for (int i = 0; i < vectorsQuerys.Count; i++)
            {
                Console.WriteLine("Query "+(i+1) + " " + querys[i] );
                for (int j = 0; j < docs.Length; j++)
                {
                    Console.Write("Doc" + j + "\t");
                }
                Console.WriteLine();

                vectorsQuerys[i].PrintResult();
                
                Console.WriteLine("\n");
            }




        }
        //static double[][] result;
        private static void init()
        {
            
            querys = q.ToList();

            foreach (string doc in docs)
            {
                var words = doc.Split(' ');
                foreach (string word in words)
                {
                    if (!terms.Contains(word) && word.Length > 3
                        //  && word != "and" && word != "or" && word !="in" && word!="not" && word != "on" && word !="of"
                        )
                        terms.Add(word);
                }
            }


            matrix = new int[terms.Count][];
            queryMatrix = new int[terms.Count][];
            //result = new double[querys.Count][];

            for (int i = 0; i < matrix.Length; i++)
            {
                matrix[i] = new int[docs.Length];
                
                queryMatrix[i] = new int[querys.Count];
                
            }
            //for (int i = 0; i < querys.Count; i++)
                //result[i] = new double[docs.Length];

           // N = docs.Length + querys.Count;
            N = docs.Length + querys.Count;

            df = new int[terms.Count];
            idf = new double[terms.Count];

                 vectors = new List<VectorSpace>();
            vectorsQuerys = new List<VectorSpaceQ>();
        }

      
        private static void BuildDocsMatrix()
        {

            //int numberOfTermes = terms.Count - querys.Count;
            for (int i = 0; i < docs.Length; i++)
            {
                
                for (int j = 0; j < terms.Count; j++)
                {
                    matrix[j][i]= Regex.Matches(docs[i], terms[j]).Count;

                    
                }
            }



        }
        private static void BuildQureysMatrix() { 

         for (int i = 0; i<queryMatrix[0].Length; i++)
            {
                for (int j = 0; j<terms.Count; j++)
                {
                    queryMatrix[j][i] = Regex.Matches(querys[i], terms[j]).Count;
                }
}
}
static void Calcule_df()
        {
            for(int i=0;i<queryMatrix.Length; i++)
                for(int j=0; j<queryMatrix[0].Length;j++)
            {
                if (queryMatrix[i][j] > 0)
                    df[i]++;
            }

            for(int i = 0; i < matrix.Length; i++)
            {
                for(int j = 0; j < matrix[0].Length; j++)
                {
                    if(matrix[i][j]>0)
                        df[i] ++;
                    
                }
                //if (df[i] != 0)
                double d = N;
                    idf[i] = Math.Log10(d / df[i]);

                //tf_idf[i] = df[i] * idf[i];

            }



        }

        static void PrintMatrix()
        {
            string line="";
            Print(terms.Count + " terms founds");
            Print("Terme-document matrix:");
            Console.Write("Term\t\t");
            for (int i = 0; i < docs.Length; i++)
                line+="Doc" + (i + 1) + "\t";


            line += "|\t";
            for (int i = 0; i < querys.Count; i++)
                line += "q"+(i+1) + "\t";

            Console.WriteLine(line);

            line="";
            for (int i = 0; i < terms.Count; i++)
            {
                line =i+" "+  terms[i] + "\t";
                if (line.Length <= 8)
                    line += "\t";

                for (int j = 0; j < matrix[0].Length; j++)
                    line += matrix[i][j] + "\t";

                line += "|\t";
                for (int j = 0; j < queryMatrix[0].Length; j++)
                {
                    line += queryMatrix[i][j] + "\t";
                }

                    Console.WriteLine(line);
            }
        }


        static void Print(object s)
        {
            Console.WriteLine(s);
        }
        static string Read()
        {
            return Console.ReadLine();
        }

        
    }
}
