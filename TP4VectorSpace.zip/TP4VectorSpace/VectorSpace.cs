﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4VectorSpace
{
    class VectorSpace
    {
        //string doc;
        public int id;
        //int[] df;
        public int[] tfrow;
        //double[] idf;
        public double[] tf_wight;
        public double[] tf_idf;
        public double[] vector_norm;
        //double[] tabL;

        public double length=0.0;
        //double d;

        
        public VectorSpace(int id, int[][] matrix)
        {
            this.id = id;
           
            this.tfrow = new int[matrix.Length];
            tf_wight = new double[matrix.Length];
            tf_idf = new double[matrix.Length];
            vector_norm = new double[matrix.Length];
            //tabL = new double[matrix.Length];

            //this.tfrow = matrix[id];

            for (int j = 0; j < matrix.Length; j++)
                this.tfrow[j] = matrix[j][id];

            //this.df = df;//df : numbre of word occurences in all docs
            //this.idf = idf;//idf = log N/df //N = docs+qeyres
          for (int i = 0; i < matrix.Length; i++)
            {
                if (tfrow[i] == 0)
                    tf_wight[i] = 0;
                else
                    tf_wight[i] = 1 + Math.Log10(tfrow[i]);

                tf_idf[i] = tf_wight[i];
                

                length += tf_idf[i] * tf_idf[i];


            }
            length = Math.Sqrt(length);

            for (int i = 0; i < matrix.Length; i++)
            {
                vector_norm[i] = tf_idf[i] / length;
                //tabL[i] = 
               // d += vector_norm[i] * tabL[i];
            }

        }

       public string round(double d)
        {
            if (d == 0)
                return "0";
            if (d == 1)
                return "1";

            return string.Format("{0:0.00}", d);
        }
        public string Print()
        {

            string t;
            t = "length = " + string.Format("{0:0.0000}", length);// + "  d= " + d + "\n";
            t += "\nterms\ttf_row\ttf_wight df\tidf\ttf_idf\tvector_norm\n";
            for (int i = 0; i < tfrow.Length; i++)
            {
                
                t += i + "\t" + tfrow[i] + "\t";
                t += round(tf_wight[i]);
                t += " \t" + Program.df[i] + "\t";

                t += round(Program.idf[i]) + "\t";
                t += round(tf_idf[i]) + "\t";

                t += round(vector_norm[i]) + "\t\t";
                //t += tabL[i];

                t += "\n";
            }
            return t;
        }


      
    }
}
