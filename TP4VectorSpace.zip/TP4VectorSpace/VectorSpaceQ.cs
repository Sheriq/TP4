﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4VectorSpace
{
    class VectorSpaceQ : VectorSpace
    {
        public double[] result;
        
        public VectorSpaceQ(int id, int[][] matrix, int nbrDocs) : base(id, matrix)
        {
            result = new double[nbrDocs];

            for (int d = 0; d < matrix.Length; d++)
            {
                tf_idf[d] = tf_wight[d] * Program.idf[d];
                vector_norm[d] = tf_idf[d] / length;
            }

            for (int d = 0; d < nbrDocs; d++)
            {   
                for (int i = 0; i < vector_norm.Length; i++)
                {
                    result[d] += (Program.vectors[d].vector_norm[i] * vector_norm[i]);
                }
                
            }
        }

        public void PrintResult()
        {
            for (int d = 0; d < result.Length; d++)
                Console.Write(round(result[d]) + "\t");

            //return "";
        }

    }
}
